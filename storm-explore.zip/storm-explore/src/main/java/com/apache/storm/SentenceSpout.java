package com.apache.storm;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.Utils;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
* @Package com.citicbank.storm 
* @author Administrator   
* @date 2020/2/9 0009 上午 11:45  
* @Description:
*/
 
public class SentenceSpout extends BaseRichSpout {

    private ConcurrentHashMap<UUID, Values> pending;

    private SpoutOutputCollector collector;

    private String[] sentences = {
            "my dog has sentences",
            "i like cold beverages",
            "the dog ate my homework",
            "do not have a cow man",
            "i do not know i like fleas"
    };

    private int index = 0;

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
        outputFieldsDeclarer.declare(new Fields("sentence"));
    }

    @Override
    public void open(Map map, TopologyContext topologyContext, SpoutOutputCollector spoutOutputCollector) {
        this.collector = spoutOutputCollector;
        this.pending = new ConcurrentHashMap<UUID, Values>();
    }

    @Override
    public void nextTuple() {
        Values values = new Values(sentences[index]);
        UUID msgId = UUID.randomUUID();
        this.pending.put(msgId, values);
        this.collector.emit(values, msgId);
        index++;
        if (index >= sentences.length) {
            index = 0;
        }
        Utils.sleep(1000L);
    }

    @Override
    public void ack(Object msgId) {
        System.out.println("msgId:" + msgId + "已确认");
        this.pending.remove(msgId);

    }

    @Override
    public void fail(Object msgId) {
        System.out.println("msgId:" + msgId + "重新发送");
        this.collector.emit(this.pending.get(msgId), msgId);
    }
}
