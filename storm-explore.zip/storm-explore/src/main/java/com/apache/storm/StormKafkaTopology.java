package com.apache.storm;

import com.apache.util.TimeUtils;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.kafka.*;
import org.apache.storm.spout.SchemeAsMultiScheme;
import org.apache.storm.topology.TopologyBuilder;

import java.util.UUID;

/**
* @Package com.apache.storm 
* @author Administrator   
* @date 2020/2/15 0015 下午 9:32  
* @Description:
*/
 
public class StormKafkaTopology {

    private static final String TOPOLOGY_NAME = "kafka-word-count-topology";

    private static final String KAFKA_SPOUT_ID = "kafka-spout";
    private static final String KAFKA_COUNT_BOLT_ID = "kafka-count-bolt";
    private static final String KAFKA_REPORT_BOLT_ID = "kafka-report-bolt";


    public static void main(String[] args) throws Exception{

        BrokerHosts hosts = new ZkHosts("49.234.8.204");
        SpoutConfig spoutConfig = new SpoutConfig(hosts, "storm-kafka-topic", "/" + "storm-kafka-topic", UUID.randomUUID().toString());
        spoutConfig.scheme = new SchemeAsMultiScheme(new WordScheme());
        KafkaSpout kafkaSpout = new KafkaSpout(spoutConfig);
        TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout(KAFKA_SPOUT_ID, kafkaSpout, 1);
        builder.setBolt(KAFKA_COUNT_BOLT_ID, new WordCountBolt(), 1).globalGrouping(KAFKA_SPOUT_ID);
        builder.setBolt(KAFKA_REPORT_BOLT_ID, new ReportBolt()).globalGrouping(KAFKA_COUNT_BOLT_ID);
        builder.createTopology();

        Config config = new Config();

        if (args.length == 0) {
            LocalCluster localCluster = new LocalCluster();
            localCluster.submitTopology(TOPOLOGY_NAME, config, builder.createTopology());
            TimeUtils.waitForSeconds(5000L);
        } else {
            StormSubmitter.submitTopology(args[0], config, builder.createTopology());
        }
    }


}
