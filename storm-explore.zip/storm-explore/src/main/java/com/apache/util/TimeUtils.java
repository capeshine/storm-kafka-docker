package com.apache.util;
 
public class TimeUtils {

    public static void waitForSeconds(Long time){
        Long begin = System.currentTimeMillis();
        boolean flag = true;
        while (flag) {
            Long end = System.currentTimeMillis();
            Long dist = end - begin;
            if (dist > time) {
                flag = false;
            }
        }
    }
}
