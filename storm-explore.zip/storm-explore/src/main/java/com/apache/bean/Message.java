package com.apache.bean;

import lombok.Data;

import java.util.Date;

/**
* @Package com.apache.bean 
* @author Administrator   
* @date 2020/2/14 0014 下午 8:56  
* @Description:
*/

@Data
public class Message {

    private long id;
    private String msg;
    private Date sendTime;

}
