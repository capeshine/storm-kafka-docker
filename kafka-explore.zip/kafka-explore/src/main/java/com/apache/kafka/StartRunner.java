package com.apache.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
* @Package com.apache.kafka 
* @author Administrator   
* @date 2020/2/15 0015 下午 4:10  
* @Description:
*/
@Component
public class StartRunner implements ApplicationRunner {

    @Autowired
    private KafkaProducer kafkaProducer;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        kafkaProducer.send();
    }
}
