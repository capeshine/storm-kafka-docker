package com.apache.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
* @Package com.apache.kafka 
* @author Administrator   
* @date 2020/2/14 0014 下午 8:53  
* @Description:
*/

@RequestMapping("/kafka")
@RestController
public class KafkaController {

    @Autowired
    private KafkaProducer producer;

    @Autowired
    private KafkaConsumers consumer;

    @RequestMapping("/sendMsg")
    public String testSendMsg(){
        producer.send();
        return "success";
    }

    @RequestMapping("/readMsg")
    public String testReadMsg(){
        consumer.consume();
        return "success";
    }


}
