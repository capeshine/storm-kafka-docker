package com.apache.kafka;

import com.apache.bean.Message;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

/**
* @Package com.apache.kafka 
* @author Administrator   
* @date 2020/2/14 0014 下午 8:54  
* @Description:
*/

@Component
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private volatile boolean flag = true;

    private Gson gson = new GsonBuilder().create();

    public void send() {
        while(flag) {
            Message message = new Message();
            message.setId(generatorRandom());
            message.setMsg(UUID.randomUUID().toString() + "---" + generatorRandom());
            message.setSendTime(new Date());
            System.out.println("发送消息:" + gson.toJson(message));
            kafkaTemplate.send("storm-kafka-topic", gson.toJson(message));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public int generatorRandom() {
        int random = RandomUtils.nextInt(1, 100);
        return random;
    }


}
